## 03‑openHands.md — *coming soon*

OpenHands uses the same idea but via a GraphQL mutation.  We’ll publish a
reference adapter + SDL here once the upstream spec stabilises (ETA Q3 2025).

*Subscribe to [@attach‑dev](https://twitter.com/attach_dev) for updates.*