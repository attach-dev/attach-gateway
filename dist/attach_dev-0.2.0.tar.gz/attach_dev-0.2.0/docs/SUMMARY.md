# Summary

* [Attach Gateway](design.md)
* [Installation](installation.md)
* [Examples](examples.md)
* Agent Hand‑offs with Attach
  * [Introduction](agent-handoffs/01-intro.md)
  * [Worked example: Google A2A](agent-handoffs/02-google-a2a.md)
  * [openHands (coming soon)](agent-handoffs/03-opensHands.md)